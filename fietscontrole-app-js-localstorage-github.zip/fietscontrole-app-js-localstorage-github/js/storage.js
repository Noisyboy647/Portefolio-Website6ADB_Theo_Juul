/**
 * StorageHandler Module
 * Handles all LocalStorage operations with caching for performance
 */
class StorageHandler {
    constructor() {
        this.keys = {
            USERS: 'users',
            CONTROLEPUNTEN: 'controlepunten',
            FIETSEN: 'fietsen',
            SESSIES: 'sessies',
            CONTROLES: 'controles',
            CURRENT_USER: 'currentUser'
        };
        
        // Cache for frequently accessed data
        this.cache = {};
        this.cacheTimeout = 100; // ms
        
        // Initialize seed data if not exists
        if (!this.get(this.keys.USERS)) {
            this.initSeedData();
        }
    }

    /**
     * Initialize localStorage with seed data
     */
    initSeedData() {
        const controlepunten = [
            { id: 1, naam: "Voorlicht" },
            { id: 2, naam: "Achterlicht" },
            { id: 3, naam: "Reflectoren voor" },
            { id: 4, naam: "Reflectoren achter" },
            { id: 5, naam: "Reflectoren pedalen" },
            { id: 6, naam: "Reflectoren spaken" },
            { id: 7, naam: "Bel" },
            { id: 8, naam: "Remmen voor" },
            { id: 9, naam: "Remmen achter" },
            { id: 10, naam: "Banden" },
            { id: 11, naam: "Handvatten" },
            { id: 12, naam: "Zadelhoogte" },
            { id: 13, naam: "Ketting" },
            { id: 14, naam: "Trappers" },
            { id: 15, naam: "Algemene staat" }
        ];

        const users = [
            {
                id: 1,
                naam: "Admin User",
                gebruikersnaam: "admin",
                wachtwoord: "admin123",
                rol: "Admin",
                klas: null
            },
            {
                id: 2,
                naam: "Janssen Jan",
                gebruikersnaam: "leerkracht",
                wachtwoord: "leerkracht123",
                rol: "Leerkracht",
                klas: null
            },
            {
                id: 3,
                naam: "Pietersen Piet",
                gebruikersnaam: "leerling",
                wachtwoord: "leerling123",
                rol: "Leerling",
                klas: "3A"
            },
            {
                id: 4,
                naam: "Jansen Marie",
                gebruikersnaam: "marie",
                wachtwoord: "marie123",
                rol: "Leerling",
                klas: "3B"
            }
        ];

        const fietsen = [
            {
                id: 1,
                leerling_id: 3,
                merk: "Gazelle",
                type: "Stadsfiets",
                framenummer: "GAZ123456",
                kleur: "Zwart"
            },
            {
                id: 2,
                leerling_id: 3,
                merk: "Batavus",
                type: "Mountainbike",
                framenummer: "BAT789012",
                kleur: "Rood"
            },
            {
                id: 3,
                leerling_id: 4,
                merk: "Giant",
                type: "Racefiets",
                framenummer: "GIA345678",
                kleur: "Blauw"
            }
        ];

        const sessies = [
            {
                id: 1,
                naam: "Verkeersweek 2026",
                actief: true
            },
            {
                id: 2,
                naam: "Verkeersweek 2025",
                actief: false
            }
        ];

        this.set(this.keys.CONTROLEPUNTEN, controlepunten);
        this.set(this.keys.USERS, users);
        this.set(this.keys.FIETSEN, fietsen);
        this.set(this.keys.SESSIES, sessies);
        this.set(this.keys.CONTROLES, []);
        this.set(this.keys.CURRENT_USER, null);
    }

    /**
     * Get data from localStorage with caching
     */
    get(key) {
        // Check cache first
        if (this.cache[key] && Date.now() - this.cache[key].timestamp < this.cacheTimeout) {
            return this.cache[key].data;
        }

        try {
            const data = localStorage.getItem(key);
            const parsed = data ? JSON.parse(data) : null;
            
            // Update cache
            this.cache[key] = {
                data: parsed,
                timestamp: Date.now()
            };
            
            return parsed;
        } catch (error) {
            console.error(`Error getting data for key ${key}:`, error);
            return null;
        }
    }

    /**
     * Set data in localStorage and invalidate cache
     */
    set(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            // Invalidate cache
            delete this.cache[key];
            return true;
        } catch (error) {
            console.error(`Error setting data for key ${key}:`, error);
            throw error;
        }
    }

    /**
     * Invalidate all cache
     */
    invalidateCache() {
        this.cache = {};
    }

    /**
     * Update specific item in array
     */
    update(key, id, updates) {
        try {
            const items = this.get(key) || [];
            const index = items.findIndex(item => item.id === id);
            
            if (index === -1) {
                console.error(`Item with id ${id} not found in ${key}`);
                return false;
            }

            items[index] = { ...items[index], ...updates };
            this.set(key, items);
            return true;
        } catch (error) {
            console.error(`Error updating item in ${key}:`, error);
            return false;
        }
    }

    /**
     * Delete item from array
     */
    delete(key, id) {
        try {
            const items = this.get(key) || [];
            const filtered = items.filter(item => item.id !== id);
            
            if (filtered.length === items.length) {
                console.error(`Item with id ${id} not found in ${key}`);
                return false;
            }

            this.set(key, filtered);
            return true;
        } catch (error) {
            console.error(`Error deleting item from ${key}:`, error);
            return false;
        }
    }

    /**
     * Add new item to array
     */
    add(key, item) {
        try {
            const items = this.get(key) || [];
            const maxId = items.length > 0 ? Math.max(...items.map(i => i.id)) : 0;
            const newItem = { ...item, id: maxId + 1 };
            items.push(newItem);
            this.set(key, items);
            return newItem.id;
        } catch (error) {
            console.error(`Error adding item to ${key}:`, error);
            throw error;
        }
    }

    /**
     * Export all data as JSON
     */
    exportData() {
        try {
            this.invalidateCache(); // Get fresh data
            const data = {
                users: this.get(this.keys.USERS),
                controlepunten: this.get(this.keys.CONTROLEPUNTEN),
                fietsen: this.get(this.keys.FIETSEN),
                sessies: this.get(this.keys.SESSIES),
                controles: this.get(this.keys.CONTROLES)
            };
            return JSON.stringify(data, null, 2);
        } catch (error) {
            console.error('Error exporting data:', error);
            throw error;
        }
    }

    /**
     * Import data from JSON string
     */
    importData(jsonString) {
        try {
            const data = JSON.parse(jsonString);
            
            if (!data.users || !data.controlepunten || !data.fietsen || !data.sessies || !data.controles) {
                throw new Error('Invalid data structure');
            }

            this.set(this.keys.USERS, data.users);
            this.set(this.keys.CONTROLEPUNTEN, data.controlepunten);
            this.set(this.keys.FIETSEN, data.fietsen);
            this.set(this.keys.SESSIES, data.sessies);
            this.set(this.keys.CONTROLES, data.controles);
            
            this.invalidateCache();
            return true;
        } catch (error) {
            console.error('Error importing data:', error);
            return false;
        }
    }
}

// Create global instance
const storage = new StorageHandler();
