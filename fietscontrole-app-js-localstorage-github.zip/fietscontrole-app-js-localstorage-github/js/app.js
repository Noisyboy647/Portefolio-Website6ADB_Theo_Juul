/**
 * Main Application Module
 * Handles SPA routing and view management with optimized performance
 */
class App {
    constructor() {
        this.currentView = null;
        this.initialized = false;
        this.init();
    }

    /**
     * Initialize application
     */
    init() {
        if (this.initialized) return;
        this.initialized = true;

        // Setup event listeners once
        window.addEventListener('hashchange', () => this.handleRoute());
        document.addEventListener('click', (e) => this.handleClick(e));

        // Initial route
        if (!auth.isLoggedIn()) {
            this.showLogin();
        } else {
            const hash = window.location.hash.slice(1);
            if (!hash || hash === '') {
                this.redirectToDefault();
            } else {
                this.handleRoute();
            }
        }
    }

    /**
     * Handle routing based on hash
     */
    handleRoute() {
        const hash = window.location.hash.slice(1);
        
        if (!auth.isLoggedIn() && hash !== 'logout') {
            this.showLogin();
            return;
        }

        this.updateNavigation();

        const routes = {
            'login': () => this.showLogin(),
            'logout': () => this.handleLogout(),
            'admin': () => auth.isAdmin() ? this.showAdmin() : this.redirectToDefault(),
            'data': () => auth.isAdmin() ? this.showDataManagement() : this.redirectToDefault(),
            'inspection': () => auth.isLeerkracht() ? this.showInspection() : this.redirectToDefault(),
            'results': () => auth.isLeerling() ? this.showResults() : this.redirectToDefault(),
            'reporting': () => auth.isLeerkracht() ? this.showReporting() : this.redirectToDefault()
        };

        const handler = routes[hash] || this.redirectToDefault;
        handler();
    }

    /**
     * Update navigation based on user role
     */
    updateNavigation() {
        const nav = document.getElementById('mainNav');
        if (!nav) return;

        const userInfo = document.getElementById('userInfo');
        const navInspection = document.getElementById('navInspection');
        const navResults = document.getElementById('navResults');
        const navReporting = document.getElementById('navReporting');
        const navAdmin = document.getElementById('navAdmin');
        const navData = document.getElementById('navData');

        if (auth.isLoggedIn()) {
            nav.style.display = 'block';
            const user = auth.getCurrentUser();
            if (userInfo) userInfo.textContent = `${user.naam} (${user.rol})`;
            
            // Show/hide menu items based on role
            if (auth.isAdmin()) {
                if (navInspection) navInspection.style.display = 'none';
                if (navResults) navResults.style.display = 'none';
                if (navReporting) navReporting.style.display = 'none';
                if (navAdmin) navAdmin.style.display = 'block';
                if (navData) navData.style.display = 'block';
            } else if (auth.isLeerkracht()) {
                if (navInspection) navInspection.style.display = 'block';
                if (navResults) navResults.style.display = 'none';
                if (navReporting) navReporting.style.display = 'block';
                if (navAdmin) navAdmin.style.display = 'none';
                if (navData) navData.style.display = 'none';
            } else if (auth.isLeerling()) {
                if (navInspection) navInspection.style.display = 'none';
                if (navResults) navResults.style.display = 'block';
                if (navReporting) navReporting.style.display = 'none';
                if (navAdmin) navAdmin.style.display = 'none';
                if (navData) navData.style.display = 'none';
            }
        } else {
            nav.style.display = 'none';
        }
    }

    /**
     * Show login view
     */
    showLogin() {
        const container = this.getContainer();
        if (!container) return;

        container.innerHTML = `
            <div class="row justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="card">
                        <div class="card-header text-center">
                            <h4>Fietscontrole Applicatie</h4>
                            <p class="mb-0">GTI Verkeersweek</p>
                        </div>
                        <div class="card-body">
                            <form id="loginForm">
                                <div class="form-group">
                                    <label for="gebruikersnaam">Gebruikersnaam</label>
                                    <input type="text" class="form-control" id="gebruikersnaam" required autofocus>
                                </div>
                                <div class="form-group">
                                    <label for="wachtwoord">Wachtwoord</label>
                                    <input type="password" class="form-control" id="wachtwoord" required>
                                </div>
                                <div id="loginError" class="alert alert-danger" style="display: none;"></div>
                                <button type="submit" class="btn btn-primary btn-block">Inloggen</button>
                            </form>
                            <div class="mt-3">
                                <small class="text-muted">
                                    <strong>Demo accounts:</strong><br>
                                    Admin: admin / admin123<br>
                                    Leerkracht: leerkracht / leerkracht123<br>
                                    Leerling: leerling / leerling123
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Setup login form handler
        const form = document.getElementById('loginForm');
        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                const gebruikersnaam = document.getElementById('gebruikersnaam')?.value;
                const wachtwoord = document.getElementById('wachtwoord')?.value;
                const errorDiv = document.getElementById('loginError');

                if (!gebruikersnaam || !wachtwoord) {
                    if (errorDiv) {
                        errorDiv.textContent = 'Vul alle velden in';
                        errorDiv.style.display = 'block';
                    }
                    return;
                }

                const user = auth.login(gebruikersnaam, wachtwoord);
                if (user) {
                    if (errorDiv) errorDiv.style.display = 'none';
                    this.redirectToDefault();
                } else {
                    if (errorDiv) {
                        errorDiv.textContent = 'Ongeldige gebruikersnaam of wachtwoord';
                        errorDiv.style.display = 'block';
                    }
                }
            });
        }
    }

    /**
     * Redirect to default view based on role
     */
    redirectToDefault() {
        if (auth.isAdmin()) {
            window.location.hash = 'admin';
            this.showAdmin();
        } else if (auth.isLeerkracht()) {
            window.location.hash = 'reporting';
            this.showReporting();
        } else if (auth.isLeerling()) {
            window.location.hash = 'results';
            this.showResults();
        } else {
            window.location.hash = 'login';
            this.showLogin();
        }
    }

    /**
     * Show inspection view
     */
    showInspection() {
        if (typeof inspectionHandler !== 'undefined' && inspectionHandler) {
            inspectionHandler.render();
        }
    }

    /**
     * Show results view for students
     */
    showResults() {
        if (typeof resultsHandler !== 'undefined' && resultsHandler) {
            resultsHandler.render();
        }
    }

    /**
     * Show reporting view for teachers
     */
    showReporting() {
        if (typeof reportingHandler !== 'undefined' && reportingHandler) {
            reportingHandler.render();
        }
    }

    /**
     * Show admin view
     */
    showAdmin() {
        if (typeof adminHandler !== 'undefined' && adminHandler) {
            adminHandler.render();
        }
    }

    /**
     * Show data management view
     */
    showDataManagement() {
        const container = this.getContainer();
        if (!container) return;

        container.innerHTML = `
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Data Beheer</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h6>Export Data</h6>
                                    <p>Download alle applicatie data als JSON bestand voor backup doeleinden.</p>
                                    <button id="exportBtn" class="btn btn-primary">
                                        <span class="mr-2">📥</span>Export Data
                                    </button>
                                </div>
                                <div class="col-md-6">
                                    <h6>Import Data</h6>
                                    <p>Upload een JSON bestand om data te herstellen of te importeren.</p>
                                    <div class="form-group">
                                        <input type="file" id="importFile" class="form-control-file" accept=".json">
                                    </div>
                                    <button id="importBtn" class="btn btn-success" disabled>
                                        <span class="mr-2">📤</span>Import Data
                                    </button>
                                    <div id="importError" class="alert alert-danger mt-2" style="display: none;"></div>
                                    <div id="importSuccess" class="alert alert-success mt-2" style="display: none;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Export functionality
        const exportBtn = document.getElementById('exportBtn');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => {
                try {
                    const data = storage.exportData();
                    const blob = new Blob([data], { type: 'application/json' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `fietscontrole-backup-${new Date().toISOString().split('T')[0]}.json`;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                } catch (error) {
                    alert('Fout bij exporteren: ' + error.message);
                }
            });
        }

        // Import functionality
        const importFile = document.getElementById('importFile');
        const importBtn = document.getElementById('importBtn');
        const importError = document.getElementById('importError');
        const importSuccess = document.getElementById('importSuccess');

        if (importFile) {
            importFile.addEventListener('change', (e) => {
                if (importBtn) {
                    importBtn.disabled = !(e.target.files.length > 0);
                }
            });
        }

        if (importBtn) {
            importBtn.addEventListener('click', () => {
                const file = importFile?.files[0];
                if (!file) return;

                const reader = new FileReader();
                reader.onload = (e) => {
                    try {
                        const jsonString = e.target.result;
                        if (storage.importData(jsonString)) {
                            if (importError) importError.style.display = 'none';
                            if (importSuccess) {
                                importSuccess.textContent = 'Data succesvol geïmporteerd! De pagina wordt herladen...';
                                importSuccess.style.display = 'block';
                            }
                            setTimeout(() => window.location.reload(), 2000);
                        } else {
                            throw new Error('Import mislukt');
                        }
                    } catch (error) {
                        if (importError) {
                            importError.textContent = 'Fout bij importeren: ' + error.message;
                            importError.style.display = 'block';
                        }
                        if (importSuccess) importSuccess.style.display = 'none';
                    }
                };
                reader.readAsText(file);
            });
        }
    }

    /**
     * Handle logout
     */
    handleLogout() {
        auth.logout();
        window.location.hash = 'login';
        this.showLogin();
    }

    /**
     * Handle click events (event delegation)
     */
    handleClick(e) {
        if (e.target.id === 'logoutLink' || e.target.closest('#logoutLink')) {
            e.preventDefault();
            this.handleLogout();
        }
    }

    /**
     * Get main container element
     */
    getContainer() {
        return document.getElementById('mainContainer');
    }
}

// Initialize app when DOM and dependencies are ready
(function() {
    function initApp() {
        const container = document.getElementById('mainContainer');
        if (!container) {
            setTimeout(initApp, 50);
            return;
        }
        
        if (typeof storage === 'undefined' || typeof auth === 'undefined') {
            setTimeout(initApp, 50);
            return;
        }
        
        new App();
    }
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initApp);
    } else {
        setTimeout(initApp, 100);
    }
})();
