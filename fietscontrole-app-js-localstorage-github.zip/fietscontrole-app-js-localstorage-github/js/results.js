/**
 * Results Module
 * Displays inspection results for students with optimized rendering
 */
class ResultsHandler {
    constructor() {
        this.setupGlobalListeners();
    }

    /**
     * Setup global event listeners
     */
    setupGlobalListeners() {
        document.addEventListener('change', (e) => {
            if (e.target.id === 'filterSessie') {
                this.updateResults();
            }
        });
    }

    /**
     * Render results view
     */
    render() {
        const currentUser = auth.getCurrentUser();
        if (!currentUser || !auth.isLeerling()) {
            return;
        }

        const container = document.getElementById('mainContainer');
        if (!container) return;

        container.innerHTML = `
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Mijn Fietscontrole Resultaten</h5>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="filterSessie">Filter op Sessie</label>
                                <select class="form-control" id="filterSessie">
                                    <option value="">Alle sessies</option>
                                </select>
                            </div>
                            <div id="resultsContainer">${this.renderResults()}</div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        this.populateSessieFilter();
    }

    /**
     * Render results list
     */
    renderResults() {
        const currentUser = auth.getCurrentUser();
        const controles = storage.get(storage.keys.CONTROLES) || [];
        const sessieFilter = document.getElementById('filterSessie')?.value || '';
        
        let studentControles = controles.filter(c => c.leerling_id === currentUser.id);
        
        if (sessieFilter) {
            studentControles = studentControles.filter(c => c.sessie_id === parseInt(sessieFilter));
        }

        if (studentControles.length === 0) {
            return '<div class="alert alert-info">Geen controles gevonden.</div>';
        }

        const sessies = storage.get(storage.keys.SESSIES) || [];
        const fietsen = storage.get(storage.keys.FIETSEN) || [];
        const controlepunten = storage.get(storage.keys.CONTROLEPUNTEN) || [];

        return studentControles.map(controle => {
            const sessie = sessies.find(s => s.id === controle.sessie_id);
            const fiets = fietsen.find(f => f.id === controle.fiets_id);
            
            const okCount = controle.controlepunten.filter(cp => cp.status === 'OK').length;
            const foutCount = controle.controlepunten.filter(cp => cp.status === 'Fout').length;

            const controlepuntenHTML = controle.controlepunten.map(cp => {
                const punt = controlepunten.find(p => p.id === cp.controlepunt_id);
                const statusBadge = cp.status === 'OK' 
                    ? '<span class="badge badge-success">OK</span>'
                    : '<span class="badge badge-danger">Fout</span>';
                return `
                    <tr>
                        <td>${punt ? punt.naam : 'Onbekend'}</td>
                        <td>${statusBadge}</td>
                        <td>${cp.opmerking || '-'}</td>
                    </tr>
                `;
            }).join('');

            return `
                <div class="card mb-3">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div>
                            <strong>Sessie:</strong> ${sessie ? sessie.naam : 'Onbekend'} | 
                            <strong>Datum:</strong> ${new Date(controle.datum).toLocaleDateString('nl-NL')}
                        </div>
                        <div>
                            <span class="badge badge-success mr-2">OK: ${okCount}</span>
                            <span class="badge badge-danger">Fout: ${foutCount}</span>
                        </div>
                    </div>
                    <div class="card-body">
                        ${fiets ? `
                            <p>
                            <strong>Fiets:</strong> ${fiets.merk} ${fiets.type} (${fiets.kleur})${fiets.framenummer ? ` - ${fiets.framenummer}` : ''}
                            </p>` : ''}
                        <h6>Controlepunten:</h6>
                        <div class="table-responsive">
                            <table class="table table-sm table-hover">
                                <thead>
                                    <tr>
                                        <th>Controlepunt</th>
                                        <th>Status</th>
                                        <th>Opmerking</th>
                                    </tr>
                                </thead>
                                <tbody>${controlepuntenHTML}</tbody>
                            </table>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }

    /**
     * Populate session filter
     */
    populateSessieFilter() {
        const sessies = storage.get(storage.keys.SESSIES) || [];
        const select = document.getElementById('filterSessie');
        
        if (!select) return;

        while (select.options.length > 1) {
            select.remove(1);
        }

        sessies.forEach(sessie => {
            const option = document.createElement('option');
            option.value = sessie.id;
            option.textContent = sessie.naam;
            select.appendChild(option);
        });
    }

    /**
     * Update results display
     */
    updateResults() {
        const container = document.getElementById('resultsContainer');
        if (container) {
            container.innerHTML = this.renderResults();
        }
    }
}

// Create global instance
const resultsHandler = new ResultsHandler();
