/**
 * Inspection Form Module
 * Handles 4-step inspection workflow with optimized event handling
 */
class InspectionHandler {
    constructor() {
        this.currentStep = 1;
        this.selectedLeerling = null;
        this.selectedSessie = null;
        this.selectedFiets = null;
        this.controleData = {};
        this.setupGlobalListeners();
    }

    /**
     * Setup global event listeners
     */
    setupGlobalListeners() {
        // Use event delegation for radio buttons and navigation
        document.addEventListener('change', (e) => {
            if (e.target.type === 'radio' && e.target.name.startsWith('controle_')) {
                const puntId = parseInt(e.target.name.split('_')[1]);
                const status = e.target.value;
                this.handleControlepuntChange(puntId, status);
            }
        });

        document.addEventListener('input', (e) => {
            if (e.target.id && e.target.id.startsWith('opmerking_')) {
                const puntId = parseInt(e.target.id.split('_')[1]);
                const opmerking = e.target.value;
                if (!this.controleData[puntId]) {
                    this.controleData[puntId] = { status: '', opmerking: '' };
                }
                this.controleData[puntId].opmerking = opmerking;
            }
        });

        document.addEventListener('click', (e) => {
            if (e.target.id === 'prevBtn') {
                e.preventDefault();
                this.goToPreviousStep();
            } else if (e.target.id === 'nextBtn') {
                e.preventDefault();
                this.goToNextStep();
            } else if (e.target.id === 'saveBtn') {
                e.preventDefault();
                this.saveControle();
            }
        });
    }

    /**
     * Handle controlepunt status change
     */
    handleControlepuntChange(puntId, status) {
        if (!this.controleData[puntId]) {
            this.controleData[puntId] = { status: '', opmerking: '' };
        }
        
        this.controleData[puntId].status = status;
        
        const commentField = document.getElementById(`comment_${puntId}`);
        if (commentField) {
            if (status === 'Fout') {
                commentField.classList.add('show');
            } else {
                commentField.classList.remove('show');
                this.controleData[puntId].opmerking = '';
                const opmerkingField = document.getElementById(`opmerking_${puntId}`);
                if (opmerkingField) opmerkingField.value = '';
            }
        }
    }

    /**
     * Render inspection form
     */
    render() {
        const container = document.getElementById('mainContainer');
        if (!container) return;

        container.innerHTML = `
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Fietscontrole Formulier</h5>
                        </div>
                        <div class="card-body">
                            <div class="step-indicator">
                                <div class="step ${this.currentStep >= 1 ? 'active' : ''} ${this.currentStep > 1 ? 'completed' : ''}">
                                    <div class="step-number">1</div>
                                    <div>Leerling</div>
                                </div>
                                <div class="step ${this.currentStep >= 2 ? 'active' : ''} ${this.currentStep > 2 ? 'completed' : ''}">
                                    <div class="step-number">2</div>
                                    <div>Sessie</div>
                                </div>
                                <div class="step ${this.currentStep >= 3 ? 'active' : ''} ${this.currentStep > 3 ? 'completed' : ''}">
                                    <div class="step-number">3</div>
                                    <div>Fiets</div>
                                </div>
                                <div class="step ${this.currentStep >= 4 ? 'active' : ''}">
                                    <div class="step-number">4</div>
                                    <div>Controle</div>
                                </div>
                            </div>

                            <div id="stepContent">${this.renderStepContent()}</div>

                            <div class="d-flex justify-content-between mt-4">
                                <button class="btn btn-secondary" id="prevBtn" style="display: ${this.currentStep > 1 ? 'block' : 'none'};">
                                    Vorige
                                </button>
                                <button class="btn btn-primary ml-auto" id="nextBtn" style="display: ${this.currentStep < 4 ? 'block' : 'none'};">
                                    Volgende
                                </button>
                                <button class="btn btn-success ml-auto" id="saveBtn" style="display: ${this.currentStep === 4 ? 'block' : 'none'};">
                                    Opslaan
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        this.setupStepListeners();
    }

    /**
     * Setup step-specific listeners
     */
    setupStepListeners() {
        const leerlingSelect = document.getElementById('leerlingSelect');
        const sessieSelect = document.getElementById('sessieSelect');
        const fietsSelect = document.getElementById('fietsSelect');

        if (leerlingSelect) {
            leerlingSelect.value = this.selectedLeerling || '';
            leerlingSelect.addEventListener('change', (e) => {
                this.selectedLeerling = e.target.value ? parseInt(e.target.value) : null;
            });
        }

        if (sessieSelect) {
            sessieSelect.value = this.selectedSessie || '';
            sessieSelect.addEventListener('change', (e) => {
                this.selectedSessie = e.target.value ? parseInt(e.target.value) : null;
            });
        }

        if (fietsSelect) {
            fietsSelect.value = this.selectedFiets || '';
            fietsSelect.addEventListener('change', (e) => {
                this.selectedFiets = e.target.value ? parseInt(e.target.value) : null;
            });
        }
    }

    /**
     * Render step content
     */
    renderStepContent() {
        const steps = {
            1: () => this.renderStep1(),
            2: () => this.renderStep2(),
            3: () => this.renderStep3(),
            4: () => this.renderStep4()
        };
        return steps[this.currentStep] ? steps[this.currentStep]() : '';
    }

    /**
     * Render Step 1: Leerling Selection
     */
    renderStep1() {
        const users = storage.get(storage.keys.USERS) || [];
        const leerlingen = users.filter(u => u.rol === 'Leerling');

        let options = '<option value="">Selecteer leerling...</option>';
        leerlingen.forEach(leerling => {
            const selected = this.selectedLeerling === leerling.id ? 'selected' : '';
            options += `<option value="${leerling.id}" ${selected}>${leerling.naam} (${leerling.klas || 'Geen klas'})</option>`;
        });

        return `<div class="form-group">
            <label for="leerlingSelect">Selecteer Leerling *</label>
            <select class="form-control" id="leerlingSelect" required>
                ${options}
            </select>
        </div>`;
    }

    /**
     * Render Step 2: Sessie Selection
     */
    renderStep2() {
        const sessies = storage.get(storage.keys.SESSIES) || [];
        const actieveSessies = sessies.filter(s => s.actief);

        let options = '<option value="">Selecteer sessie...</option>';
        actieveSessies.forEach(sessie => {
            const selected = this.selectedSessie === sessie.id ? 'selected' : '';
            options += `<option value="${sessie.id}" ${selected}>${sessie.naam}</option>`;
        });

        return `<div class="form-group">
            <label for="sessieSelect">Selecteer Sessie *</label>
            <select class="form-control" id="sessieSelect" required>
                ${options}
            </select>
        </div>`;
    }

    /**
     * Render Step 3: Fiets Selection
     */
    renderStep3() {
        if (!this.selectedLeerling) {
            return '<div class="alert alert-warning">Selecteer eerst een leerling in stap 1.</div>';
        }

        const fietsen = storage.get(storage.keys.FIETSEN) || [];
        const leerlingFietsen = fietsen.filter(f => f.leerling_id === this.selectedLeerling);

        if (leerlingFietsen.length === 0) {
            return '<div class="alert alert-warning">Geen fietsen gevonden voor deze leerling.</div>';
        }

        let options = '<option value="">Selecteer fiets...</option>';
        leerlingFietsen.forEach(fiets => {
            const selected = this.selectedFiets === fiets.id ? 'selected' : '';
            // Check of framenummer bestaat: zo ja, voeg streepje en nummer toe, zo nee, laat leeg.
            const framenummerDisplay = fiets.framenummer ? ` - ${fiets.framenummer}` : ''; 
            options += `<option value="${fiets.id}" ${selected}>${fiets.merk} ${fiets.type} (${fiets.kleur})${framenummerDisplay}</option>`;
        });

        return `<div class="form-group">
            <label for="fietsSelect">Selecteer Fiets *</label>
            <select class="form-control" id="fietsSelect" required>
                ${options}
            </select>
        </div>`;
    }

    /**
     * Render Step 4: Controle Checklist
     */
renderStep4() {
    const controlepunten = storage.get(storage.keys.CONTROLEPUNTEN) || [];
    const fietsen = storage.get(storage.keys.FIETSEN) || [];
    const fiets = fietsen.find(f => f.id === this.selectedFiets);

    // Maak het framenummer optioneel voor de weergave
    const framenummerDisplay = fiets && fiets.framenummer ? ` - ${fiets.framenummer}` : '';

    let checklist = controlepunten.map(punt => {
        const controleValue = this.controleData[punt.id] || { status: '', opmerking: '' };
        return `
            <div class="inspection-point">
                <label>${punt.naam} *</label>
                <div class="radio-group">
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="controle_${punt.id}" 
                               id="ok_${punt.id}" value="OK" ${controleValue.status === 'OK' ? 'checked' : ''}>
                        <label class="form-check-label" for="ok_${punt.id}">OK</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="controle_${punt.id}" 
                               id="fout_${punt.id}" value="Fout" ${controleValue.status === 'Fout' ? 'checked' : ''}>
                        <label class="form-check-label" for="fout_${punt.id}">Fout</label>
                    </div>
                </div>
                <div class="comment-field ${controleValue.status === 'Fout' ? 'show' : ''}" id="comment_${punt.id}">
                    <label for="opmerking_${punt.id}">Opmerking</label>
                    <textarea class="form-control" id="opmerking_${punt.id}" rows="2" 
                              placeholder="Geef een specifieke opmerking...">${controleValue.opmerking || ''}</textarea>
                </div>
            </div>
        `;
    }).join('');

    return `
        <div class="alert alert-info">
            <strong>Geselecteerde fiets:</strong> ${fiets ? `${fiets.merk} ${fiets.type} (${fiets.kleur})${framenummerDisplay}` : 'Onbekend'}
        </div>
        <div class="alert alert-info">
            <strong>Controleer alle punten:</strong> Selecteer voor elk controlepunt of het OK of Fout is. 
            Bij "Fout" is een opmerking verplicht.
        </div>
        ${checklist}
    `;
}
    /**
     * Go to previous step
     */
    goToPreviousStep() {
        if (this.currentStep > 1) {
            this.currentStep--;
            this.render();
        }
    }

    /**
     * Go to next step
     */
    goToNextStep() {
        if (this.currentStep === 1 && !this.selectedLeerling) {
            alert('Selecteer een leerling');
            return;
        }
        if (this.currentStep === 2 && !this.selectedSessie) {
            alert('Selecteer een sessie');
            return;
        }
        if (this.currentStep === 3 && !this.selectedFiets) {
            alert('Selecteer een fiets');
            return;
        }

        if (this.currentStep < 4) {
            this.currentStep++;
            this.render();
        }
    }

    /**
     * Save controle
     */
    saveControle() {
        const controlepunten = storage.get(storage.keys.CONTROLEPUNTEN) || [];
        const missing = [];
        const missingComments = [];

        controlepunten.forEach(punt => {
            const data = this.controleData[punt.id];
            if (!data || !data.status) {
                missing.push(punt.naam);
            } else if (data.status === 'Fout' && (!data.opmerking || data.opmerking.trim() === '')) {
                missingComments.push(punt.naam);
            }
        });

        if (missing.length > 0) {
            alert(`Controleer de volgende punten: ${missing.join(', ')}`);
            return;
        }

        if (missingComments.length > 0) {
            alert(`Geef een opmerking voor de volgende punten: ${missingComments.join(', ')}`);
            return;
        }

        const controlepuntenData = controlepunten.map(punt => {
            const data = this.controleData[punt.id];
            return {
                controlepunt_id: punt.id,
                status: data.status,
                opmerking: data.status === 'Fout' ? data.opmerking : null
            };
        });

        const controle = {
            fiets_id: this.selectedFiets,
            sessie_id: this.selectedSessie,
            leerling_id: this.selectedLeerling,
            datum: new Date().toISOString().split('T')[0],
            controlepunten: controlepuntenData
        };

        try {
            storage.add(storage.keys.CONTROLES, controle);
            
            // Reset form
            this.currentStep = 1;
            this.selectedLeerling = null;
            this.selectedSessie = null;
            this.selectedFiets = null;
            this.controleData = {};
            
            alert('Controle succesvol opgeslagen!');
            this.render();
        } catch (error) {
            alert('Fout bij opslaan: ' + error.message);
        }
    }
}

// Create global instance
const inspectionHandler = new InspectionHandler();
