/**
 * Reporting Module
 * Provides reporting functionality for teachers with debounced filtering
 */
class ReportingHandler {
    constructor() {
        this.filterTimeout = null;
        this.setupGlobalListeners();
    }

    /**
     * Setup global event listeners with debouncing
     */
    setupGlobalListeners() {
        document.addEventListener('change', (e) => {
            // HIGHLIGHT: Luister naar klas wijziging om leerlingenlijst te updaten
            if (e.target.id === 'reportKlas') {
                this.updateLeerlingDropdown();
            }

            if (['reportSessie', 'reportKlas', 'reportLeerling', 'reportControlepunt'].includes(e.target.id)) {
                clearTimeout(this.filterTimeout);
                this.filterTimeout = setTimeout(() => {
                    this.updateReport();
                }, 150);
            }
        });

        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('view-details')) {
                e.preventDefault();
                const controleId = parseInt(e.target.getAttribute('data-id'));
                this.showDetails(controleId);
            }
        });
    }

    /**
     * Render reporting view
     */
    render() {
        const container = document.getElementById('mainContainer');
        if (!container) return;

        container.innerHTML = `
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Rapportage</h5>
                        </div>
                        <div class="card-body">
                            <div class="row mb-4">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="reportSessie">Sessie</label>
                                        <select class="form-control" id="reportSessie">
                                            <option value="">Alle sessies</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="reportKlas">Klas</label>
                                        <select class="form-control" id="reportKlas">
                                            <option value="">Alle klassen</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="reportLeerling">Leerling</label>
                                        <select class="form-control" id="reportLeerling">
                                            <option value="">Alle leerlingen</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="reportControlepunt">Controlepunt</label>
                                        <select class="form-control" id="reportControlepunt">
                                            <option value="">Alle controlepunten</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row mb-4" id="summaryCards">${this.renderSummaryCards()}</div>

                            <div class="table-responsive">
                                <table class="table table-hover" id="reportTable">
                                    <thead>
                                        <tr>
                                            <th>Datum</th><th>Leerling</th><th>Klas</th><th>Sessie</th>
                                            <th>Fiets</th><th>Status</th><th>Details</th>
                                        </tr>
                                    </thead>
                                    <tbody id="reportTableBody">${this.renderReportTable()}</tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        this.populateFilters();
    }

    /**
     * Render summary cards
     */
    renderSummaryCards() {
        const data = this.getFilteredData();
        
        const totalControles = data.controles.length;
        const totalOK = data.controles.reduce((sum, c) => 
            sum + c.controlepunten.filter(cp => cp.status === 'OK').length, 0);
        const totalFout = data.controles.reduce((sum, c) => 
            sum + c.controlepunten.filter(cp => cp.status === 'Fout').length, 0);
        const totalPunten = data.controles.reduce((sum, c) => sum + c.controlepunten.length, 0);
        const percentageOK = totalPunten > 0 ? Math.round((totalOK / totalPunten) * 100) : 0;

        return `
            <div class="col-md-3">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <h6>Totaal Controles</h6>
                        <h3>${totalControles}</h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h6>OK Punten</h6>
                        <h3>${totalOK}</h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-danger text-white">
                    <div class="card-body">
                        <h6>Fout Punten</h6>
                        <h3>${totalFout}</h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <h6>OK Percentage</h6>
                        <h3>${percentageOK}%</h3>
                    </div>
                </div>
            </div>
        `;
    }

    /**
     * Render report table
     */
    renderReportTable() {
        const data = this.getFilteredData();
        const controlepuntFilter = document.getElementById('reportControlepunt')?.value || '';
        
        if (data.controles.length === 0) {
            return '<tr><td colspan="7" class="text-center">Geen controles gevonden met de geselecteerde filters.</td></tr>';
        }

        const users = storage.get(storage.keys.USERS) || [];
        const sessies = storage.get(storage.keys.SESSIES) || [];
        const fietsen = storage.get(storage.keys.FIETSEN) || [];
        const controlepunten = storage.get(storage.keys.CONTROLEPUNTEN) || [];

        return data.controles.map(controle => {
            const leerling = users.find(u => u.id === controle.leerling_id);
            const sessie = sessies.find(s => s.id === controle.sessie_id);
            const fiets = fietsen.find(f => f.id === controle.fiets_id);
            
            const okCount = controle.controlepunten.filter(cp => cp.status === 'OK').length;
            const foutCount = controle.controlepunten.filter(cp => cp.status === 'Fout').length;
            const statusBadge = foutCount === 0 
                ? '<span class="badge badge-success">Goed</span>'
                : foutCount <= 3
                ? '<span class="badge badge-warning">Aandacht</span>'
                : '<span class="badge badge-danger">Problemen</span>';

            let controlepuntStatus = '';
            if (controlepuntFilter) {
                const controlepuntId = parseInt(controlepuntFilter);
                const cp = controle.controlepunten.find(cp => cp.controlepunt_id === controlepuntId);
                if (cp) {
                    const cpNaam = controlepunten.find(p => p.id === controlepuntId)?.naam || 'Onbekend';
                    const cpStatusBadge = cp.status === 'OK' 
                        ? '<span class="badge badge-success">OK</span>'
                        : '<span class="badge badge-danger">Fout</span>';
                    controlepuntStatus = `<br><small><strong>${cpNaam}:</strong> ${cpStatusBadge}${cp.opmerking ? ' - ' + cp.opmerking : ''}</small>`;
                }
            }

            return `
                <tr>
                    <td>${new Date(controle.datum).toLocaleDateString('nl-NL')}</td>
                    <td>${leerling ? leerling.naam : 'Onbekend'}</td>
                    <td>${leerling && leerling.klas ? leerling.klas : '-'}</td>
                    <td>${sessie ? sessie.naam : 'Onbekend'}</td>
                    <td>${fiets ? `${fiets.merk} ${fiets.type}` : 'Onbekend'}</td>
                    <td>${statusBadge} (${okCount} OK, ${foutCount} Fout)${controlepuntStatus}</td>
                    <td>
                        <button class="btn btn-sm btn-info view-details" data-id="${controle.id}">Details</button>
                    </td>
                </tr>
            `;
        }).join('');
    }

    /**
     * Get filtered data based on current filters
     */
    getFilteredData() {
        const sessieFilter = document.getElementById('reportSessie')?.value || '';
        const klasFilter = document.getElementById('reportKlas')?.value || '';
        const leerlingFilter = document.getElementById('reportLeerling')?.value || '';
        const controlepuntFilter = document.getElementById('reportControlepunt')?.value || '';

        let controles = storage.get(storage.keys.CONTROLES) || [];
        const users = storage.get(storage.keys.USERS) || [];

        if (sessieFilter) {
            controles = controles.filter(c => c.sessie_id === parseInt(sessieFilter));
        }

        if (klasFilter) {
            const leerlingenInKlas = users
                .filter(u => u.rol === 'Leerling' && u.klas === klasFilter)
                .map(u => u.id);
            controles = controles.filter(c => leerlingenInKlas.includes(c.leerling_id));
        }

        if (leerlingFilter) {
            controles = controles.filter(c => c.leerling_id === parseInt(leerlingFilter));
        }

        if (controlepuntFilter) {
            const controlepuntId = parseInt(controlepuntFilter);
            controles = controles.filter(c => {
                return c.controlepunten && c.controlepunten.some(cp => cp.controlepunt_id === controlepuntId);
            });
        }

        return { controles, users };
    }

    /**
     * Populate filter dropdowns
     */
    populateFilters() {
        const sessies = storage.get(storage.keys.SESSIES) || [];
        const users = storage.get(storage.keys.USERS) || [];
        const controlepunten = storage.get(storage.keys.CONTROLEPUNTEN) || [];

        const sessieSelect = document.getElementById('reportSessie');
        if (sessieSelect) {
            sessies.forEach(sessie => {
                const option = document.createElement('option');
                option.value = sessie.id;
                option.textContent = sessie.naam;
                sessieSelect.appendChild(option);
            });
        }

        const klasSelect = document.getElementById('reportKlas');
        if (klasSelect) {
            const klassen = [...new Set(users
                .filter(u => u.rol === 'Leerling' && u.klas)
                .map(u => u.klas)
            )].sort();
            
            klassen.forEach(klas => {
                const option = document.createElement('option');
                option.value = klas;
                option.textContent = klas;
                klasSelect.appendChild(option);
            });
        }

        // HIGHLIGHT: Initiële vulling van leerlingen
        this.updateLeerlingDropdown();

        const controlepuntSelect = document.getElementById('reportControlepunt');
        if (controlepuntSelect) {
            controlepunten.forEach(punt => {
                const option = document.createElement('option');
                option.value = punt.id;
                option.textContent = punt.naam;
                controlepuntSelect.appendChild(option);
            });
        }
    }

    /**
     * HIGHLIGHT: Dynamische update van leerlingenlijst op basis van geselecteerde klas
     */
    updateLeerlingDropdown() {
        const users = storage.get(storage.keys.USERS) || [];
        const klasFilter = document.getElementById('reportKlas')?.value || '';
        const leerlingSelect = document.getElementById('reportLeerling');

        if (!leerlingSelect) return;

        // Reset dropdown (behalve de eerste optie)
        while (leerlingSelect.options.length > 1) {
            leerlingSelect.remove(1);
        }

        let leerlingen = users.filter(u => u.rol === 'Leerling');

        // Filter op klas indien geselecteerd
        if (klasFilter) {
            leerlingen = leerlingen.filter(u => u.klas === klasFilter);
        }

        leerlingen.sort((a, b) => a.naam.localeCompare(b.naam));
        
        leerlingen.forEach(leerling => {
            const option = document.createElement('option');
            option.value = leerling.id;
            option.textContent = `${leerling.naam}${leerling.klas && !klasFilter ? ' (' + leerling.klas + ')' : ''}`;
            leerlingSelect.appendChild(option);
        });
    }

    /**
     * Update report based on filters
     */
    updateReport() {
        const summaryCards = document.getElementById('summaryCards');
        const tableBody = document.getElementById('reportTableBody');
        
        if (summaryCards) summaryCards.innerHTML = this.renderSummaryCards();
        if (tableBody) tableBody.innerHTML = this.renderReportTable();
    }

    /**
     * Show details modal
     */
    showDetails(controleId) {
        const controles = storage.get(storage.keys.CONTROLES) || [];
        const controle = controles.find(c => c.id === controleId);
        
        if (!controle) return;

        const users = storage.get(storage.keys.USERS) || [];
        const sessies = storage.get(storage.keys.SESSIES) || [];
        const fietsen = storage.get(storage.keys.FIETSEN) || [];
        const controlepunten = storage.get(storage.keys.CONTROLEPUNTEN) || [];

        const leerling = users.find(u => u.id === controle.leerling_id);
        const sessie = sessies.find(s => s.id === controle.sessie_id);
        const fiets = fietsen.find(f => f.id === controle.fiets_id);

        const detailsHTML = controle.controlepunten.map(cp => {
            const punt = controlepunten.find(p => p.id === cp.controlepunt_id);
            const statusBadge = cp.status === 'OK' 
                ? '<span class="badge badge-success">OK</span>'
                : '<span class="badge badge-danger">Fout</span>';
            
            return `
                <tr>
                    <td>${punt ? punt.naam : 'Onbekend'}</td>
                    <td>${statusBadge}</td>
                    <td>${cp.opmerking || '-'}</td>
                </tr>
            `;
        }).join('');

        const modalHtml = `
            <div class="modal fade" id="detailsModal" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Controle Details</h5>
                            <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                        </div>
                        <div class="modal-body">
                            <p><strong>Leerling:</strong> ${leerling ? leerling.naam : 'Onbekend'}</p>
                            <p><strong>Klas:</strong> ${leerling && leerling.klas ? leerling.klas : '-'}</p>
                            <p><strong>Sessie:</strong> ${sessie ? sessie.naam : 'Onbekend'}</p>
                            <p><strong>Datum:</strong> ${new Date(controle.datum).toLocaleDateString('nl-NL')}</p>
                            ${fiets ? `
                                <p>
                                    <strong>Fiets:</strong> ${fiets.merk} ${fiets.type} (${fiets.kleur})${fiets.framenummer ? ` - ${fiets.framenummer}` : ''}
                                </p>` : ''}
                            <hr>
                            <h6>Controlepunten:</h6>
                            <table class="table table-sm">
                                <thead>
                                    <tr><th>Controlepunt</th><th>Status</th><th>Opmerking</th></tr>
                                </thead>
                                <tbody>${detailsHTML}</tbody>
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Sluiten</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        const existingModal = document.getElementById('detailsModal');
        if (existingModal) existingModal.remove();

        document.body.insertAdjacentHTML('beforeend', modalHtml);
        $('#detailsModal').modal('show');

        $('#detailsModal').on('hidden.bs.modal', function () {
            $(this).remove();
        });
    }
}

// Create global instance
const reportingHandler = new ReportingHandler();