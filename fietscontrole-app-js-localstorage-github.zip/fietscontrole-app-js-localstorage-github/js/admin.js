/**
 * Admin Dashboard Module
 * Handles user, bike and session management (CRUD operations)
 * Optimized with event delegation and caching
 */
class AdminHandler {
    constructor() {
        this.editingUserId = null;
        this.editingFietsId = null;
        this.editingSessieId = null;
        this.setupGlobalListeners();
    }

    /**
     * Setup global event listeners (once)
     */
    setupGlobalListeners() {
        // Use event delegation for all table actions
        document.addEventListener('click', (e) => {
            const target = e.target;
            
            // User actions
            if (target.classList.contains('edit-user')) {
                e.preventDefault();
                this.editUser(parseInt(target.getAttribute('data-id')));
            } else if (target.classList.contains('delete-user')) {
                e.preventDefault();
                this.deleteUser(parseInt(target.getAttribute('data-id')));
            }
            // Fiets actions
            else if (target.classList.contains('edit-fiets')) {
                e.preventDefault();
                this.editFiets(parseInt(target.getAttribute('data-id')));
            } else if (target.classList.contains('delete-fiets')) {
                e.preventDefault();
                this.deleteFiets(parseInt(target.getAttribute('data-id')));
            }
            // Sessie actions
            else if (target.classList.contains('edit-sessie')) {
                e.preventDefault();
                this.editSessie(parseInt(target.getAttribute('data-id')));
            } else if (target.classList.contains('delete-sessie')) {
                e.preventDefault();
                this.deleteSessie(parseInt(target.getAttribute('data-id')));
            }
            // Form actions
            else if (target.id === 'addUserBtn') {
                e.preventDefault();
                this.showUserModal();
            } else if (target.id === 'addFietsBtn') {
                e.preventDefault();
                this.showFietsModal();
            } else if (target.id === 'addSessieBtn') {
                e.preventDefault();
                this.showSessieModal();
            } else if (target.id === 'saveUserBtn') {
                e.preventDefault();
                this.saveUser();
            } else if (target.id === 'saveFietsBtn') {
                e.preventDefault();
                this.saveFiets();
            } else if (target.id === 'saveSessieBtn') {
                e.preventDefault();
                this.saveSessie();
            }
        });

        // Role change handler (event delegation)
        document.addEventListener('change', (e) => {
            if (e.target.id === 'userRol') {
                const klasGroup = document.getElementById('klasGroup');
                if (klasGroup) {
                    klasGroup.style.display = e.target.value === 'Leerling' ? 'block' : 'none';
                }
            }
        });
    }

    /**
     * Render admin dashboard
     */
    render() {
        const container = document.getElementById('mainContainer');
        if (!container) return;

        container.innerHTML = `
            <ul class="nav nav-tabs mb-3" id="adminTabs" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="users-tab" data-toggle="tab" href="#users" role="tab">Gebruikers</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="fietsen-tab" data-toggle="tab" href="#fietsen" role="tab">Fietsen</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="sessies-tab" data-toggle="tab" href="#sessies" role="tab">Sessies</a>
                </li>
            </ul>

            <div class="tab-content" id="adminTabContent">
                <div class="tab-pane fade show active" id="users" role="tabpanel">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Gebruikersbeheer</h5>
                            <button class="btn btn-primary btn-sm" id="addUserBtn">+ Nieuwe Gebruiker</button>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Naam</th><th>Gebruikersnaam</th><th>Rol</th><th>Klas</th><th>Acties</th>
                                        </tr>
                                    </thead>
                                    <tbody id="usersTableBody">${this.renderUsersTable()}</tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="tab-pane fade" id="fietsen" role="tabpanel">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Fietsbeheer</h5>
                            <button class="btn btn-primary btn-sm" id="addFietsBtn">+ Nieuwe Fiets</button>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Merk</th><th>Type</th><th>Kleur</th><th>Framenummer</th><th>Leerling</th><th>Klas</th><th>Acties</th>
                                        </tr>
                                    </thead>
                                    <tbody id="fietsenTableBody">${this.renderFietsenTable()}</tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="tab-pane fade" id="sessies" role="tabpanel">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Sessiebeheer</h5>
                            <button class="btn btn-primary btn-sm" id="addSessieBtn">+ Nieuwe Sessie</button>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr><th>Naam</th><th>Status</th><th>Acties</th></tr>
                                    </thead>
                                    <tbody id="sessiesTableBody">${this.renderSessiesTable()}</tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            ${this.getUserModalHTML()}
        `;
    }

    /**
     * Render users table
     */
    renderUsersTable() {
        const users = storage.get(storage.keys.USERS) || [];
        if (users.length === 0) {
            return '<tr><td colspan="5" class="text-center">Geen gebruikers gevonden</td></tr>';
        }

        return users.map(user => {
            const badgeClass = this.getBadgeClass(user.rol);
            return `
                <tr>
                    <td>${this.escapeHtml(user.naam)}</td>
                    <td>${this.escapeHtml(user.gebruikersnaam)}</td>
                    <td><span class="badge ${badgeClass}">${this.escapeHtml(user.rol)}</span></td>
                    <td>${user.klas ? this.escapeHtml(user.klas) : '-'}</td>
                    <td>
                        <button class="btn btn-sm btn-info edit-user" data-id="${user.id}">Bewerken</button>
                        <button class="btn btn-sm btn-danger delete-user" data-id="${user.id}">Verwijderen</button>
                    </td>
                </tr>
            `;
        }).join('');
    }

    /**
     * Render fietsen table
     */
    renderFietsenTable() {
        const fietsen = storage.get(storage.keys.FIETSEN) || [];
        const users = storage.get(storage.keys.USERS) || [];
        
        if (fietsen.length === 0) {
            return '<tr><td colspan="7" class="text-center">Geen fietsen gevonden</td></tr>';
        }

        return fietsen.map(fiets => {
            const leerling = users.find(u => u.id === fiets.leerling_id);
            return `
                <tr>
                    <td>${this.escapeHtml(fiets.merk)}</td>
                    <td>${this.escapeHtml(fiets.type)}</td>
                    <td>${this.escapeHtml(fiets.kleur)}</td>
                    <td>${this.escapeHtml(fiets.framenummer)}</td>
                    <td>${leerling ? this.escapeHtml(leerling.naam) : 'Onbekend'}</td>
                    <td>${leerling && leerling.klas ? this.escapeHtml(leerling.klas) : '-'}</td>
                    <td>
                        <button class="btn btn-sm btn-info edit-fiets" data-id="${fiets.id}">Bewerken</button>
                        <button class="btn btn-sm btn-danger delete-fiets" data-id="${fiets.id}">Verwijderen</button>
                    </td>
                </tr>
            `;
        }).join('');
    }

    /**
     * Render sessies table
     */
    renderSessiesTable() {
        const sessies = storage.get(storage.keys.SESSIES) || [];
        
        if (sessies.length === 0) {
            return '<tr><td colspan="3" class="text-center">Geen sessies gevonden</td></tr>';
        }

        return sessies.map(sessie => {
            const statusBadge = sessie.actief 
                ? '<span class="badge badge-success">Actief</span>'
                : '<span class="badge badge-secondary">Inactief</span>';
            return `
                <tr>
                    <td>${this.escapeHtml(sessie.naam)}</td>
                    <td>${statusBadge}</td>
                    <td>
                        <button class="btn btn-sm btn-info edit-sessie" data-id="${sessie.id}">Bewerken</button>
                        <button class="btn btn-sm btn-danger delete-sessie" data-id="${sessie.id}">Verwijderen</button>
                    </td>
                </tr>
            `;
        }).join('');
    }

    /**
     * Get badge class for role
     */
    getBadgeClass(rol) {
        const badges = {
            'Admin': 'badge-dark',
            'Leerkracht': 'badge-info',
            'Leerling': 'badge-secondary'
        };
        return badges[rol] || 'badge-secondary';
    }

    /**
     * Escape HTML to prevent XSS
     */
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * Get user modal HTML
     */
    getUserModalHTML() {
        return `
            <div class="modal fade" id="userModal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="userModalTitle">Nieuwe Gebruiker</h5>
                            <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                        </div>
                        <div class="modal-body">
                            <form id="userForm">
                                <div class="form-group">
                                    <label for="userNaam">Naam *</label>
                                    <input type="text" class="form-control" id="userNaam" required>
                                </div>
                                <div class="form-group">
                                    <label for="userGebruikersnaam">Gebruikersnaam *</label>
                                    <input type="text" class="form-control" id="userGebruikersnaam" required>
                                </div>
                                <div class="form-group">
                                    <label for="userWachtwoord">Wachtwoord *</label>
                                    <input type="password" class="form-control" id="userWachtwoord" required minlength="6">
                                    <small class="form-text text-muted">Minimaal 6 tekens</small>
                                </div>
                                <div class="form-group">
                                    <label for="userRol">Rol *</label>
                                    <select class="form-control" id="userRol" required>
                                        <option value="">Selecteer rol...</option>
                                        <option value="Admin">Admin</option>
                                        <option value="Leerkracht">Leerkracht</option>
                                        <option value="Leerling">Leerling</option>
                                    </select>
                                </div>
                                <div class="form-group" id="klasGroup" style="display: none;">
                                    <label for="userKlas">Klas</label>
                                    <input type="text" class="form-control" id="userKlas">
                                </div>
                                <div id="userFormError" class="alert alert-danger" style="display: none;"></div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuleren</button>
                            <button type="button" class="btn btn-primary" id="saveUserBtn">Opslaan</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    /**
     * Show user modal
     */
    showUserModal(userId = null) {
        this.editingUserId = userId;
        const modal = document.getElementById('userModal');
        if (!modal) return;

        const title = document.getElementById('userModalTitle');
        const form = document.getElementById('userForm');
        const klasGroup = document.getElementById('klasGroup');
        
        if (title) title.textContent = userId ? 'Gebruiker Bewerken' : 'Nieuwe Gebruiker';
        if (form) form.reset();
        if (klasGroup) klasGroup.style.display = 'none';
        
        const errorDiv = document.getElementById('userFormError');
        if (errorDiv) errorDiv.style.display = 'none';

        if (userId) {
            const users = storage.get(storage.keys.USERS) || [];
            const user = users.find(u => u.id === userId);
            if (user) {
                const naamEl = document.getElementById('userNaam');
                const gebruikersnaamEl = document.getElementById('userGebruikersnaam');
                const wachtwoordEl = document.getElementById('userWachtwoord');
                const rolEl = document.getElementById('userRol');
                const klasEl = document.getElementById('userKlas');
                
                if (naamEl) naamEl.value = user.naam;
                if (gebruikersnaamEl) gebruikersnaamEl.value = user.gebruikersnaam;
                if (wachtwoordEl) {
                    wachtwoordEl.value = '';
                    wachtwoordEl.required = false;
                }
                if (rolEl) {
                    rolEl.value = user.rol;
                    if (klasGroup) klasGroup.style.display = user.rol === 'Leerling' ? 'block' : 'none';
                }
                if (klasEl && user.klas) klasEl.value = user.klas;
            }
        }

        $('#userModal').modal('show');
    }

    /**
     * Save user
     */
    saveUser() {
        const naam = document.getElementById('userNaam')?.value.trim();
        const gebruikersnaam = document.getElementById('userGebruikersnaam')?.value.trim();
        const wachtwoord = document.getElementById('userWachtwoord')?.value;
        const rol = document.getElementById('userRol')?.value;
        const klas = rol === 'Leerling' ? document.getElementById('userKlas')?.value.trim() : null;
        const errorDiv = document.getElementById('userFormError');

        if (!naam || !gebruikersnaam || !rol) {
            if (errorDiv) {
                errorDiv.textContent = 'Vul alle verplichte velden in';
                errorDiv.style.display = 'block';
            }
            return;
        }

        const users = storage.get(storage.keys.USERS) || [];
        const existingUser = users.find(u => 
            u.gebruikersnaam === gebruikersnaam && 
            (!this.editingUserId || u.id !== this.editingUserId)
        );

        if (existingUser) {
            if (errorDiv) {
                errorDiv.textContent = 'Deze gebruikersnaam bestaat al';
                errorDiv.style.display = 'block';
            }
            return;
        }

        if (!this.editingUserId && (!wachtwoord || wachtwoord.length < 6)) {
            if (errorDiv) {
                errorDiv.textContent = 'Wachtwoord moet minimaal 6 tekens lang zijn';
                errorDiv.style.display = 'block';
            }
            return;
        }

        try {
            if (this.editingUserId) {
                const updates = { naam, gebruikersnaam, rol, klas };
                if (wachtwoord && wachtwoord.length >= 6) {
                    updates.wachtwoord = wachtwoord;
                }
                storage.update(storage.keys.USERS, this.editingUserId, updates);
            } else {
                storage.add(storage.keys.USERS, { naam, gebruikersnaam, wachtwoord, rol, klas });
            }

            $('#userModal').modal('hide');
            this.render();
        } catch (error) {
            if (errorDiv) {
                errorDiv.textContent = 'Fout bij opslaan: ' + error.message;
                errorDiv.style.display = 'block';
            }
        }
    }

    /**
     * Edit user
     */
    editUser(userId) {
        this.showUserModal(userId);
    }

    /**
     * Delete user
     */
    deleteUser(userId) {
        const users = storage.get(storage.keys.USERS) || [];
        const user = users.find(u => u.id === userId);
        if (!user) return;

        const currentUser = auth.getCurrentUser();
        if (currentUser && currentUser.id === userId) {
            alert('Je kunt je eigen account niet verwijderen');
            return;
        }

        if (confirm(`Weet je zeker dat je ${user.naam} wilt verwijderen?`)) {
            storage.delete(storage.keys.USERS, userId);
            this.render();
        }
    }

    /**
     * Show fiets modal
     */
    showFietsModal(fietsId = null) {
        this.editingFietsId = fietsId;
        const users = storage.get(storage.keys.USERS) || [];
        const leerlingen = users.filter(u => u.rol === 'Leerling');
        
        let leerlingOptions = '<option value="">Selecteer leerling...</option>';
        leerlingen.forEach(leerling => {
            leerlingOptions += `<option value="${leerling.id}">${this.escapeHtml(leerling.naam)} (${leerling.klas || 'Geen klas'})</option>`;
        });

        const modalHtml = `
            <div class="modal fade" id="fietsModal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">${fietsId ? 'Fiets Bewerken' : 'Nieuwe Fiets'}</h5>
                            <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                        </div>
                        <div class="modal-body">
                            <form id="fietsForm">
                                <div class="form-group">
                                    <label for="fietsMerk">Merk *</label>
                                    <input type="text" class="form-control" id="fietsMerk" required>
                                </div>
                                <div class="form-group">
                                    <label for="fietsType">Type *</label>
                                    <input type="text" class="form-control" id="fietsType" required>
                                </div>
                                <div class="form-group">
                                    <label for="fietsKleur">Kleur *</label>
                                    <input type="text" class="form-control" id="fietsKleur" required>
                                </div>
                                <div class="form-group">
                                    <label for="fietsFramenummer">Framenummer (optioneel) *</label>
                                    <input type="text" class="form-control" id="fietsFramenummer" required>
                                </div>
                                <div class="form-group">
                                    <label for="fietsLeerling">Leerling *</label>
                                    <select class="form-control" id="fietsLeerling" required>
                                        ${leerlingOptions}
                                    </select>
                                </div>
                                <div id="fietsFormError" class="alert alert-danger" style="display: none;"></div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuleren</button>
                            <button type="button" class="btn btn-primary" id="saveFietsBtn">Opslaan</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        const existingModal = document.getElementById('fietsModal');
        if (existingModal) existingModal.remove();

        document.body.insertAdjacentHTML('beforeend', modalHtml);
        
        if (fietsId) {
            const fietsen = storage.get(storage.keys.FIETSEN) || [];
            const fiets = fietsen.find(f => f.id === fietsId);
            if (fiets) {
                const merkEl = document.getElementById('fietsMerk');
                const typeEl = document.getElementById('fietsType');
                const kleurEl = document.getElementById('fietsKleur');
                const framenummerEl = document.getElementById('fietsFramenummer');
                const leerlingEl = document.getElementById('fietsLeerling');
                
                if (merkEl) merkEl.value = fiets.merk;
                if (typeEl) typeEl.value = fiets.type;
                if (kleurEl) kleurEl.value = fiets.kleur;
                if (framenummerEl) framenummerEl.value = fiets.framenummer;
                if (leerlingEl) leerlingEl.value = fiets.leerling_id;
            }
        }

        $('#fietsModal').modal('show');
        $('#fietsModal').on('hidden.bs.modal', function () {
            $(this).remove();
        });
    }

    /**
     * Save fiets
     */
    saveFiets() {
        const merk = document.getElementById('fietsMerk')?.value.trim();
        const type = document.getElementById('fietsType')?.value.trim();
        const kleur = document.getElementById('fietsKleur')?.value.trim();
        const framenummer = document.getElementById('fietsFramenummer')?.value.trim();
        const leerlingId = document.getElementById('fietsLeerling')?.value;
        const errorDiv = document.getElementById('fietsFormError');

        if (!merk || !type || !kleur || !leerlingId) {
            if (errorDiv) {
                errorDiv.textContent = 'Vul alle velden in';
                errorDiv.style.display = 'block';
            }
            return;
        }

        try {
            if (this.editingFietsId) {
                storage.update(storage.keys.FIETSEN, this.editingFietsId, {
                    merk, type, kleur, framenummer, leerling_id: parseInt(leerlingId)
                });
            } else {
                storage.add(storage.keys.FIETSEN, {
                    merk, type, kleur, framenummer, leerling_id: parseInt(leerlingId)
                });
            }

            $('#fietsModal').modal('hide');
            this.render();
        } catch (error) {
            if (errorDiv) {
                errorDiv.textContent = 'Fout bij opslaan: ' + error.message;
                errorDiv.style.display = 'block';
            }
        }
    }

    /**
     * Edit fiets
     */
    editFiets(fietsId) {
        this.showFietsModal(fietsId);
    }

    /**
     * Delete fiets
     */
    deleteFiets(fietsId) {
        if (confirm('Weet je zeker dat je deze fiets wilt verwijderen?')) {
            storage.delete(storage.keys.FIETSEN, fietsId);
            this.render();
        }
    }

    /**
     * Show sessie modal
     */
    showSessieModal(sessieId = null) {
        this.editingSessieId = sessieId;
        const modalHtml = `
            <div class="modal fade" id="sessieModal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">${sessieId ? 'Sessie Bewerken' : 'Nieuwe Sessie'}</h5>
                            <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                        </div>
                        <div class="modal-body">
                            <form id="sessieForm">
                                <div class="form-group">
                                    <label for="sessieNaam">Naam *</label>
                                    <input type="text" class="form-control" id="sessieNaam" required>
                                </div>
                                <div class="form-group">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="sessieActief">
                                        <label class="form-check-label" for="sessieActief">Actief</label>
                                    </div>
                                </div>
                                <div id="sessieFormError" class="alert alert-danger" style="display: none;"></div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuleren</button>
                            <button type="button" class="btn btn-primary" id="saveSessieBtn">Opslaan</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        const existingModal = document.getElementById('sessieModal');
        if (existingModal) existingModal.remove();

        document.body.insertAdjacentHTML('beforeend', modalHtml);
        
        if (sessieId) {
            const sessies = storage.get(storage.keys.SESSIES) || [];
            const sessie = sessies.find(s => s.id === sessieId);
            if (sessie) {
                const naamEl = document.getElementById('sessieNaam');
                const actiefEl = document.getElementById('sessieActief');
                if (naamEl) naamEl.value = sessie.naam;
                if (actiefEl) actiefEl.checked = sessie.actief;
            }
        }

        $('#sessieModal').modal('show');
        $('#sessieModal').on('hidden.bs.modal', function () {
            $(this).remove();
        });
    }

    /**
     * Save sessie
     */
    saveSessie() {
        const naam = document.getElementById('sessieNaam')?.value.trim();
        const actief = document.getElementById('sessieActief')?.checked;
        const errorDiv = document.getElementById('sessieFormError');

        if (!naam) {
            if (errorDiv) {
                errorDiv.textContent = 'Vul de naam in';
                errorDiv.style.display = 'block';
            }
            return;
        }

        try {
            if (this.editingSessieId) {
                storage.update(storage.keys.SESSIES, this.editingSessieId, { naam, actief });
            } else {
                storage.add(storage.keys.SESSIES, { naam, actief });
            }

            $('#sessieModal').modal('hide');
            this.render();
        } catch (error) {
            if (errorDiv) {
                errorDiv.textContent = 'Fout bij opslaan: ' + error.message;
                errorDiv.style.display = 'block';
            }
        }
    }

    /**
     * Edit sessie
     */
    editSessie(sessieId) {
        this.showSessieModal(sessieId);
    }

    /**
     * Delete sessie
     */
    deleteSessie(sessieId) {
        const sessies = storage.get(storage.keys.SESSIES) || [];
        const sessie = sessies.find(s => s.id === sessieId);
        if (!sessie) return;

        const controles = storage.get(storage.keys.CONTROLES) || [];
        if (controles.some(c => c.sessie_id === sessieId)) {
            alert('Deze sessie kan niet worden verwijderd omdat er controles aan gekoppeld zijn.');
            return;
        }

        if (confirm(`Weet je zeker dat je ${sessie.naam} wilt verwijderen?`)) {
            storage.delete(storage.keys.SESSIES, sessieId);
            this.render();
        }
    }
}

// Create global instance
const adminHandler = new AdminHandler();
