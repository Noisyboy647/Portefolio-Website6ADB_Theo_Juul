/**
 * Authentication Module
 * Handles login, logout, and session management
 */
class AuthHandler {
    constructor() {
        this.currentUser = null;
        this.init();
    }

    /**
     * Initialize authentication
     */
    init() {
        this.currentUser = storage.get(storage.keys.CURRENT_USER);
    }

    /**
     * Login user
     * @param {string} gebruikersnaam - Username
     * @param {string} wachtwoord - Password
     * @returns {object|null} User object or null if invalid
     */
    login(gebruikersnaam, wachtwoord) {
        const users = storage.get(storage.keys.USERS) || [];
        const user = users.find(u => 
            u.gebruikersnaam === gebruikersnaam && 
            u.wachtwoord === wachtwoord
        );

        if (user) {
            // Don't store password in currentUser
            const { wachtwoord: _, ...userWithoutPassword } = user;
            this.currentUser = userWithoutPassword;
            storage.set(storage.keys.CURRENT_USER, this.currentUser);
            return this.currentUser;
        }

        return null;
    }

    /**
     * Logout user
     */
    logout() {
        this.currentUser = null;
        storage.set(storage.keys.CURRENT_USER, null);
    }

    /**
     * Check if user is logged in
     * @returns {boolean}
     */
    isLoggedIn() {
        return this.currentUser !== null;
    }

    /**
     * Get current user
     * @returns {object|null}
     */
    getCurrentUser() {
        return this.currentUser;
    }

    /**
     * Check if user has admin role
     * @returns {boolean}
     */
    isAdmin() {
        return this.currentUser && this.currentUser.rol === 'Admin';
    }

    /**
     * Check if user is teacher
     * @returns {boolean}
     */
    isLeerkracht() {
        return this.currentUser && this.currentUser.rol === 'Leerkracht';
    }

    /**
     * Check if user is student
     * @returns {boolean}
     */
    isLeerling() {
        return this.currentUser && this.currentUser.rol === 'Leerling';
    }
}

// Create global instance
const auth = new AuthHandler();
